var searchData=
[
  ['actions_2ejs',['actions.js',['../actions_8js.html',1,'']]],
  ['actions_2emin_2ejs',['actions.min.js',['../actions_8min_8js.html',1,'']]]
];
