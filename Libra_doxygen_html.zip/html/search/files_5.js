var searchData=
[
  ['get_5fdelivery_2ejs',['get_delivery.js',['../js_2get__delivery_8js.html',1,'']]],
  ['get_5fdelivery_2ejs',['get_delivery.js',['../iles_2js_2get__delivery_8js.html',1,'']]]
];
