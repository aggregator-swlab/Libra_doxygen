var searchData=
[
  ['datetimeshortcuts_2ejs',['DateTimeShortcuts.js',['../_date_time_shortcuts_8js.html',1,'']]]
];
