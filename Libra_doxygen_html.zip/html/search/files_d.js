var searchData=
[
  ['urlify_2ejs',['urlify.js',['../urlify_8js.html',1,'']]],
  ['urls_2epy',['urls.py',['../urls_8py.html',1,'']]]
];
