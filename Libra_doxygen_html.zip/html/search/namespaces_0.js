var searchData=
[
  ['flipdelivery',['flipdelivery',['../namespaceflipdelivery.html',1,'']]]
];
