var searchData=
[
  ['imageid',['ImageId',['../classcom_1_1example_1_1harrispaul_1_1aggregator_1_1_image_id.html',1,'com::example::harrispaul::aggregator']]],
  ['imagelink',['ImageLink',['../classcom_1_1example_1_1harrispaul_1_1aggregator_1_1_my_item_1_1_image_link.html',1,'com::example::harrispaul::aggregator::MyItem']]],
  ['itemcontent',['ItemContent',['../classcom_1_1example_1_1harrispaul_1_1aggregator_1_1_item_content.html',1,'com::example::harrispaul::aggregator']]]
];
