var searchData=
[
  ['oncreate',['onCreate',['../classcom_1_1example_1_1harrispaul_1_1aggregator_1_1_deals.html#a1a837b58a00a701242a4874a6621964e',1,'com.example.harrispaul.aggregator.Deals.onCreate()'],['../classcom_1_1example_1_1harrispaul_1_1aggregator_1_1_main_activity.html#a6f19391d16916b5d43a49442be6f2f84',1,'com.example.harrispaul.aggregator.MainActivity.onCreate()']]]
];
