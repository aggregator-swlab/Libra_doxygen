var searchData=
[
  ['singleproductcustombaseadapter',['SingleProductCustomBaseAdapter',['../classcom_1_1example_1_1harrispaul_1_1aggregator_1_1_single_product_custom_base_adapter.html',1,'com::example::harrispaul::aggregator']]]
];
