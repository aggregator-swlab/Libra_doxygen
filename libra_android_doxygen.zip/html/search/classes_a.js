var searchData=
[
  ['openapp',['OpenApp',['../classcom_1_1example_1_1harrispaul_1_1aggregator_1_1_open_app.html',1,'com::example::harrispaul::aggregator']]]
];
