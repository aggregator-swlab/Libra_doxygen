var searchData=
[
  ['stringasccomparator',['StringAscComparator',['../classcom_1_1example_1_1harrispaul_1_1aggregator_1_1_main_activity.html#a550fa27a045ee79498f773f64534bd5d',1,'com::example::harrispaul::aggregator::MainActivity']]],
  ['stringdesccomparator',['StringDescComparator',['../classcom_1_1example_1_1harrispaul_1_1aggregator_1_1_main_activity.html#ae2bf9f2fe5952a01c5d2d2d2b613dfbc',1,'com::example::harrispaul::aggregator::MainActivity']]]
];
