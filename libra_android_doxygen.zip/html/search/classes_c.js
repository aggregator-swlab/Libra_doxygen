var searchData=
[
  ['r',['R',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r.html',1,'android::support::v7::appcompat']]],
  ['r',['R',['../classandroid_1_1support_1_1v7_1_1recyclerview_1_1_r.html',1,'android::support::v7::recyclerview']]],
  ['r',['R',['../classandroid_1_1support_1_1design_1_1_r.html',1,'android::support::design']]],
  ['r',['R',['../classcom_1_1example_1_1harrispaul_1_1aggregator_1_1_r.html',1,'com::example::harrispaul::aggregator']]]
];
