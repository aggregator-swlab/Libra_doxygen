var searchData=
[
  ['aggregator',['aggregator',['../namespacecom_1_1example_1_1harrispaul_1_1aggregator.html',1,'com::example::harrispaul']]],
  ['test',['test',['../namespacecom_1_1example_1_1harrispaul_1_1aggregator_1_1test.html',1,'com::example::harrispaul::aggregator']]]
];
